const steps = document.getElementsByClassName("danialForms");
let currentStep = 1;

loadStep(currentStep);

function unloadStep(id)
{
    for (const step of steps) // For each step, the condition below is checked
    {
        if(step.dataset.step == id) // This condition checks the id and unloads the form elements
        {
            let forms = step.children;
            unloadForms(forms);
        }
    }
}

function unloadForms(forms)
{
    for (const element of forms)
    {
        element.replaceChildren(); // Am empty replaceChildren() can be used as an eraser of the form elements
    }
}

function loadStep(id) // This function loads the form elements for the specific step
{
    for (const step of steps)
    {
        if(step.dataset.step == id)
        {
            let forms = step.children;
            loadForms(forms);
        } 
    }
}

function loadForms(forms) 
{ 

    for (const element of forms) 
    {
        // Sets the variables of all data attributes  
        const type = element.dataset.type;
        const text = element.dataset.text;
        const options = element.dataset.options;
        const placeholder = element.dataset.placeholder;
		const name = element.dataset.name;
        let value = element.dataset.value;

        // Only adds a textnode if defined 
        if (text != null)
        {
            const textNode = document.createTextNode(text);
            element.appendChild(textNode);
        }

        // Adds the form-elements
        const newElement = createFormElement(type, value, options, placeholder, name);
        element.appendChild(newElement);

    }

}

// This function creates form elements

function createFormElement(type, value, options, placeholder, name)
{
    if (type == "text")
    {
        return createTextField(value, placeholder); // Creates inputfield for value and with a placeholder
    }

    else if (type == "dropdown")
    {
        return createSelector(value, options); // Creates dropdown selectfield for value and with options
    }

    else if (type == "button")
    {
        return createButton(value); // Creates a button
    }

    else if (type == "radio")
    {
        return createRadio(value, options, name); // Creates a radio field
    }

    else if (type == "paragraph")
    { 
        return createParagraph(value); // Creates a custom paragraph
    }
    else if (type == "check")
    { 
        return createCheckbox(value); // Creates a checkbox
    }
}


// This function creates an input text field for a value with a placeholder
function createTextField(value, placeholder)
{
    let input = document.createElement("input");
    input.setAttribute("type", "text"); // Sets type attribute for text input

    // Adds a value if defined
    if (value != null)
    {
        input.value = value; 
    }

    // Adds a placeholder if defined
    if (placeholder != null)
    {
        input.placeholder = placeholder;
    }

    // Saving the values in the parent element
    input.addEventListener('change', function() {
        input.parentElement.dataset.value = input.value;
    });

    return input;
}


// This function creates an input selection field for a selection out of multiple values
function createSelector(value, options)
{
    const optionList = JSON.parse(options); // Changes strings into JS Arrays from HTML 
    let select = document.createElement('select'); 

    for (let optionItem of optionList){
        let option = document.createElement('option');
        option.text = optionItem; // Sets the option-text
        option.value = optionItem; // Sets the option-value

        select.appendChild(option); // Adds option to select element
    } 
    
    // Adds a value to select if defined
    if (value != null)
    {
        select.value = value;
    }

    // Saving the values in the parent element
    select.addEventListener('change', function() {
        select.parentElement.dataset.value = select.value;
    });

    return select;
}

function createButton(value)
{
    const button = document.createElement("button");

    if (value != null)
    {
        button.textContent = value;
    }

    switch (value)
    {
        case "next":
            button.addEventListener("click", next);
            break;
        case "previous":
            button.addEventListener("click", previous);
            break;
        case "submit":
            button.addEventListener("click", submit);
            break;
    }

    return button;
}

function createRadio(value, options, name)
{
	const optionList = JSON.parse(options); // Changes strings into JS Arrays from HTML 
    const radioGroup = document.createElement("div");
    
   
	for (let optionItem of optionList){ // optionItem for every item in optionList. (Array)
        let radio = document.createElement("input");
		radio.type = "radio";  // Sets the input type to radio
        radio.value = optionItem; // Sets the option-text
        radio.name = name; // Sets the option-value
		
		if (optionItem == value) 
		{
			radio.checked = true;
		}
		
		let label = document.createElement("label"); 
		label.textContent = optionItem; // Assigns the option to the label element

		radio.addEventListener('click', function() {
			let query = 'input[name="' + name + '"]:checked';
			let value = document.querySelector(query).value;
			radio.parentElement.parentElement.dataset.value = value;
		});

        radioGroup.appendChild(radio); // Adds option to radio element
		radioGroup.appendChild(label); // Adds the label to the option
    }

    return radioGroup;
}

function createParagraph(value)
{
    const paragraph = document.createElement("p");

    if (value != null)
    {
        paragraph.value = value;
    }
    
    return paragraph;
}

function createCheckbox(value)
{
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    
    if (value == "true")
    {
        checkbox.checked = true;
	}
	
    // Saving the values in the parent element after the checkbox is checked
     checkbox.addEventListener('change', function() {
        checkbox.parentElement.dataset.value = checkbox.checked;
    });
    
    return checkbox;
}

function submit() 
{
	const formData = getData();
    let formDataJson = JSON.stringify(formData);
    console.log(formDataJson);
	
	console.log(getValueOf(1,2));
}

function getValueOf(step, id)
{
	const formData = getData();
	let value = formData[step - 1][id - 1];
	return value;
}

function getData() {
	let formData = [];
    for (const step of steps)
    {
        let forms = step.children;
        let data = [];
        for (const element of forms)
        {
			const type = element.dataset.type;
			const text = element.dataset.text;
            if (type != "button" && type != "paragraph")
			{
				data.push(element.dataset.value);
			}
        }

        let stepID = step.dataset.step;
        formData[stepID - 1] = data;
    }
    return formData;
}

function next()
{
    unloadStep(currentStep);
    currentStep++;
    loadStep(currentStep);
}

function previous()
{
    unloadStep(currentStep);
    currentStep--;
    loadStep(currentStep);
}

